==============================================
Contributing Modules to the Ansible Collection
==============================================

.. toctree::
   :maxdepth: 4

   Module Architecture <architecture>
   Creating a New Ansible Module <new_module>
   Adding New Module Options <update_module>