
.. Document meta

:orphan:

.. Anchors

.. _ansible_collections.netbox.netbox.netbox_interface_module:

.. Title

netbox.netbox.netbox_interface
++++++++++++++++++++++++++++++

.. Collection note

.. note::
    This plugin was part of the `netbox.netbox collection <https://galaxy.ansible.com/netbox/netbox>`_ (version 3.14.0).

This module has been removed
in version 0.1.0 of netbox.netbox.
netbox\_interface has been superseceded by netbox.netbox.netbox\_device\_interface
