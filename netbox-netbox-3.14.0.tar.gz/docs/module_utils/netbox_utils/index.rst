netbox_utils
=================================

Constants
---------

.. autodata:: plugins.module_utils.netbox_utils.API_APPS_ENDPOINTS
.. autodata:: plugins.module_utils.netbox_utils.QUERY_TYPES
.. autodata:: plugins.module_utils.netbox_utils.CONVERT_TO_ID
.. autodata:: plugins.module_utils.netbox_utils.ENDPOINT_NAME_MAPPING
.. autodata:: plugins.module_utils.netbox_utils.ALLOWED_QUERY_PARAMS
.. autodata:: plugins.module_utils.netbox_utils.QUERY_PARAMS_IDS
.. autodata:: plugins.module_utils.netbox_utils.REQUIRED_ID_FIND
.. autodata:: plugins.module_utils.netbox_utils.CONVERT_KEYS
.. autodata:: plugins.module_utils.netbox_utils.SLUG_REQUIRED
.. autodata:: plugins.module_utils.netbox_utils.NETBOX_ARG_SPEC

Classes
-------
.. automodule:: plugins.module_utils.netbox_utils