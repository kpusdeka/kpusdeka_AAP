netbox_tenancy
====================================

Constants
---------
.. autodata:: plugins.module_utils.netbox_tenancy.NB_TENANTS
.. autodata:: plugins.module_utils.netbox_tenancy.NB_TENANT_GROUPS

Classes
-------
.. autoclass:: plugins.module_utils.netbox_tenancy.NetboxTenancyModule
