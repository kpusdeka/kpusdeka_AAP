netbox_ipam
====================================

Constants
---------
.. autodata:: plugins.module_utils.netbox_ipam.NB_AGGREGATES
.. autodata:: plugins.module_utils.netbox_ipam.NB_IP_ADDRESSES
.. autodata:: plugins.module_utils.netbox_ipam.NB_PREFIXES
.. autodata:: plugins.module_utils.netbox_ipam.NB_IPAM_ROLES
.. autodata:: plugins.module_utils.netbox_ipam.NB_RIRS
.. autodata:: plugins.module_utils.netbox_ipam.NB_VLANS
.. autodata:: plugins.module_utils.netbox_ipam.NB_VLAN_GROUPS
.. autodata:: plugins.module_utils.netbox_ipam.NB_VRFS
.. autodata:: plugins.module_utils.netbox_ipam.NB_SERVICES

Classes
-------
.. autoclass:: plugins.module_utils.netbox_ipam.NetboxIpamModule
